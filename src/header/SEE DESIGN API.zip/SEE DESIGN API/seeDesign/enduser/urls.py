from django.urls import path,include
from . import views
from rest_framework.authtoken.views import obtain_auth_token

urlpatterns = [
    path('signup/',views.userSignup.as_view()),
    path('login2/',obtain_auth_token,name='login'),
    path('login/',views.userLogin.as_view(),name='login')
]