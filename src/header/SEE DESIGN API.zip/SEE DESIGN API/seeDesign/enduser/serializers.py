from rest_framework import serializers

class signupSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    password = serializers.CharField(max_length=100)
    confirm_password = serializers.CharField(max_length=100)
    is_verified_email = serializers.BooleanField(default=False)
    is_verified_mobile = serializers.BooleanField(default=False)

class userLoginSerializer(serializers.Serializer):
    email = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=100)

