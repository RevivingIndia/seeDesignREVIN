from .serializers import *
from rest_framework.views import APIView
from django.http import JsonResponse
from .models import *
import random
import string
from django.contrib.auth.models import User
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.hashers import make_password
import requests

class userSignup(APIView):
    def post(self, request):
        serializer = signupSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.data['email']
            password = serializer.data['password']
            c_password = serializer.data['confirm_password']
            username = 'seedesign'+''.join(random.choices(string.digits+string.ascii_letters, k=random.randint(10, 14)))

            if email!='':
                if EndUser.objects.filter(email=email).exists():
                    return JsonResponse({
                        "status": 400,
                        "message": "User Already Exist With Provided Email-ID",
                    })

            EndUser.objects.create(
                email=email,
                password=password,
                username=username,
            )

            User.objects.create_user(username=username,password=password)

            return JsonResponse({
                        'status': 200,
                        'message': 'Registration Successfully',
                        'is_verified_email': serializer.data['is_verified_email'],
                        'is_verified_mobile': serializer.data['is_verified_email']
                    })

        return JsonResponse({
             'status' : 400,
             'message': 'Something Went Wrong',
              'error' : serializer.errors
        })


class userLogin(APIView):
    def post(self, request):
        try:
            data = request.data
            serializer = userLoginSerializer(data=data)
            if serializer.is_valid():
                email = serializer.data['email']
                password = serializer.data['password']

                if email != '':
                    if EndUser.objects.filter(email=email).exists():
                        data = EndUser.objects.filter(email=email).values()[0]
                        url = "http://127.0.0.1:8000/login2/"
                        cred = {"username":data['username'],"password":password }
                        login_status = requests.post(url, data = cred)
                        return Response({
                            'status': 200,
                            'message': "Login Successful",
                            'token': login_status.json(),

                        })

            return Response({
                'status': 400,
                'message': 'Something went wrong',
                'data': serializer.errors
            })
        except Exception as e:
            print(e)